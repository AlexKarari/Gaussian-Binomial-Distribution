from setuptools import setup

setup(name='distributions_probabilities',
    version='1.2',
    description='Gaussian and binomial distribution',
    packages=['distributions_probabilities'],
    author = 'Alexander Karari',
    author_email = 'mc8testmail@gmail.com',
    zip_safe=False)